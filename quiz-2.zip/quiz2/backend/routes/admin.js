const express = require('express');
const router = express.Router();
const { isAdmin } = require('../middleware/auth');

// Middleware to check if the user is an admin
router.use(isAdmin);

// Example admin route
router.get('/dashboard', (req, res) => {
    res.json({ message: 'Welcome to the Admin Dashboard!' });
});

// Create a resource
router.post('/resource', (req, res) => {
    const { name, description } = req.body;
    // Logic to create a resource in the database
    res.status(201).json({ message: 'Resource created successfully' });
});

// Read all resources
router.get('/resources', (req, res) => {
    // Logic to fetch all resources from the database
    res.json([{ id: 1, name: 'Resource 1', description: 'Description 1' }]);
});

// Update a resource
router.put('/resource/:id', (req, res) => {
    const { id } = req.params;
    const { name, description } = req.body;
    // Logic to update the resource in the database
    res.json({ message: `Resource with ID ${id} updated successfully` });
});

// Delete a resource
router.delete('/resource/:id', (req, res) => {
    const { id } = req.params;
    // Logic to delete the resource from the database
    res.json({ message: `Resource with ID ${id} deleted successfully` });
});

module.exports = router;
