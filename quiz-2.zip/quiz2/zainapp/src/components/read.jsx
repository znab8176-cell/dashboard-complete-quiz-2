import React, { useState } from 'react';
import './read.css';

function Read() {
    const [productId, setProductId] = useState('');
    const [productDetails, setProductDetails] = useState(null);

    const handleRead = (e) => {
        e.preventDefault();
        // Add logic to fetch product details using productId
        console.log(`Fetching details for product with ID ${productId}`);
        setProductDetails({
            name: 'Sample Product',
            price: 100,
        }); // Mock data for demonstration
    };

    return (
        <div className="read-product">
            <h2>Read Product</h2>
            <form onSubmit={handleRead}>
                <label htmlFor="product-id">Product ID:</label>
                <input
                    type="text"
                    id="product-id"
                    value={productId}
                    onChange={(e) => setProductId(e.target.value)}
                    placeholder="Enter Product ID"
                />
                <button type="submit">Fetch Details</button>
            </form>
            {productDetails && (
                <div className="product-details">
                    <h3>Product Details:</h3>
                    <p>Name: {productDetails.name}</p>
                    <p>Price: ${productDetails.price}</p>
                </div>
            )}
        </div>
    );
}

export default Read;
