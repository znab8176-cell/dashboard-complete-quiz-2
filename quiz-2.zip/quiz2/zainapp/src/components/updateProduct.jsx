import React, { useState } from 'react';
import './UpdateProduct.css';

function UpdateProduct() {
    const [productId, setProductId] = useState('');
    const [productDetails, setProductDetails] = useState({ name: '', price: '' });

    const handleUpdate = (e) => {
        e.preventDefault();
        // Add logic to update the product using productId and productDetails
        console.log(`Product with ID ${productId} updated with details:`, productDetails);
    };

    return (
        <div className="update-product">
            <h2>Update Product</h2>
            <form onSubmit={handleUpdate}>
                <label htmlFor="product-id">Product ID:</label>
                <input
                    type="text"
                    id="product-id"
                    value={productId}
                    onChange={(e) => setProductId(e.target.value)}
                    placeholder="Enter Product ID"
                />
                <label htmlFor="product-name">Product Name:</label>
                <input
                    type="text"
                    id="product-name"
                    value={productDetails.name}
                    onChange={(e) => setProductDetails({ ...productDetails, name: e.target.value })}
                    placeholder="Enter Product Name"
                />
                <label htmlFor="product-price">Product Price:</label>
                <input
                    type="number"
                    id="product-price"
                    value={productDetails.price}
                    onChange={(e) => setProductDetails({ ...productDetails, price: e.target.value })}
                    placeholder="Enter Product Price"
                />
                <button type="submit">Update</button>
            </form>
        </div>
    );
}

export default UpdateProduct;
