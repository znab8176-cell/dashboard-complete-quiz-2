import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import './LoadingSplash.css';

function LoadingSplash() {
  const navigate = useNavigate();
  const auth = useAuth();

  useEffect(() => {
    // Short delay before redirecting to login or dashboard if authenticated
    const t = setTimeout(() => {
      if (auth && auth.currentUser) navigate('/dashboard');
      else navigate('/login');
    }, 800); // 800ms delay
    return () => clearTimeout(t);
  }, [auth, navigate]);

  return (
    <div className="splash-page">
      <div className="splash-card">
        <img className="splash-logo" src="https://i.postimg.cc/TP6JjSTt/logo.webp" alt="Logo" />
        <h3 className="splash-title">Elite Men's Fashion</h3>
        <div className="splash-loader" aria-hidden></div>
      </div>
    </div>
  );
}

export default LoadingSplash;
