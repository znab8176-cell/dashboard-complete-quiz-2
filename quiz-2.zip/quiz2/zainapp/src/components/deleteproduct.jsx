import React, { useState } from 'react';
import './deleteproduct.css';

function DeleteProduct() {
    const [productId, setProductId] = useState('');

    const handleDelete = (e) => {
        e.preventDefault();
        // Add logic to delete the product using productId
        console.log(`Product with ID ${productId} deleted.`);
    };

    return (
        <div className="delete-product">
            <h2>Delete Product</h2>
            <form onSubmit={handleDelete}>
                <label htmlFor="product-id">Product ID:</label>
                <input
                    type="text"
                    id="product-id"
                    value={productId}
                    onChange={(e) => setProductId(e.target.value)}
                    placeholder="Enter Product ID"
                />
                <button type="submit">Delete</button>
            </form>
        </div>
    );
}

export default DeleteProduct;
