import React, { useState, useEffect } from 'react';

const AdminPanel = () => {
    const [resources, setResources] = useState([]);
    const [formData, setFormData] = useState({ name: '', description: '' });

    useEffect(() => {
        // Fetch resources on component mount
        fetch('/admin/resources')
            .then((res) => res.json())
            .then((data) => setResources(data));
    }, []);

    const handleCreate = () => {
        fetch('/admin/resource', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData),
        })
            .then((res) => res.json())
            .then(() => {
                alert('Resource created');
                setFormData({ name: '', description: '' });
            });
    };

    const handleDelete = (id) => {
        fetch(`/admin/resource/${id}`, { method: 'DELETE' })
            .then((res) => res.json())
            .then(() => {
                alert('Resource deleted');
                setResources(resources.filter((r) => r.id !== id));
            });
    };

    return (
        <div>
            <h1>Admin Panel</h1>
            <div>
                <h2>Create Resource</h2>
                <input
                    type="text"
                    placeholder="Name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                />
                <input
                    type="text"
                    placeholder="Description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                />
                <button onClick={handleCreate}>Create</button>
            </div>
            <div>
                <h2>Resources</h2>
                <ul>
                    {resources.map((resource) => (
                        <li key={resource.id}>
                            {resource.name} - {resource.description}
                            <button onClick={() => handleDelete(resource.id)}>Delete</button>
                        </li>
                    ))}
                </ul>
            </div>
        </div>
    );
};

export default AdminPanel;
