import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import AdminPanel from './pages/AdminPanel';
import About from './pages/About';
import Home from './pages/Home';
import DeleteProduct from '../../zainapp/src/components/deleteproduct';
import UpdateProduct from '../../zainapp/src/components/updateProduct'; // Import UpdateProduct
import Read from '../../zainapp/src/components/read'; // Import Read

function App() {
    return (
        <Router>
            <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/about" element={<About />} />
                <Route path="/admin" element={<AdminPanel />} />
                <Route path="/delete-product" element={<DeleteProduct />} />
                <Route path="/update-product" element={<UpdateProduct />} /> {/* Add route */}
                <Route path="/read-product" element={<Read />} /> {/* Add route */}
            </Routes>
        </Router>
    );
}

export default App;